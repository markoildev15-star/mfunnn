import io, os, tempfile, unittest, json
from pathlib import Path
scratch=tempfile.TemporaryDirectory()
os.environ['MARKOL_DATA']=scratch.name
from app import app, DATA, db
from PIL import Image

class IntegrationTests(unittest.TestCase):
    def setUp(self):
        self.client=app.test_client()
        self.client.get('/admineight')
        with self.client.session_transaction() as s: self.csrf=s['csrf']
        password=(DATA/'FIRST_LOGIN.txt').read_text().split('Password: ')[1].splitlines()[0]
        self.assertEqual(self.client.post('/admineight',data={'password':password,'csrf':self.csrf}).status_code,302)
        self.client.get('/admineight')
        with self.client.session_transaction() as s: self.csrf=s['csrf']
    def api(self,url,method='POST',data=None):
        return self.client.open(url,method=method,json=data,headers={'X-CSRF-Token':self.csrf})
    def image(self,color='red'):
        out=io.BytesIO();Image.new('RGB',(4,4),color).save(out,'PNG');out.seek(0);return out
    def test_full_flow(self):
        self.assertEqual(self.client.get('/').status_code,200)
        self.assertEqual(app.test_client().get('/api/state').status_code,401)
        self.assertEqual(self.client.post('/api/settings',json={}).status_code,403)
        r=self.client.post('/api/media',data={'file':(self.image(),'hello.png')},headers={'X-CSRF-Token':self.csrf})
        self.assertEqual(r.status_code,200);mid=r.json['id'];self.assertRegex(mid,r'^[a-f0-9]{32}$')
        with self.client.get('/media/'+mid) as response: self.assertEqual(response.status_code,200)
        with self.client.get('/media/'+mid,headers={'Range':'bytes=0-9'}) as response: self.assertEqual(response.status_code,206)
        v={'slug':'11','title':'Demo','kind':'redirect','target':'https://example.com','enabled':True,'steps':[]}
        r=self.api('/api/routes',data=v);self.assertEqual(r.status_code,200);rid=r.json['id']
        self.assertEqual(self.client.get('/11').location,'https://example.com')
        v.update(kind='scenario',steps=[{'media':mid,'seconds':2}])
        self.assertEqual(self.api('/api/routes/'+str(rid),'PUT',v).status_code,200)
        self.assertIn(b'player-data',self.client.get('/11').data)
        self.assertEqual(self.client.get('/admineight/preview/'+str(rid)).status_code,200)
        with db() as c:self.assertEqual(c.execute('SELECT hits FROM routes WHERE id=?',(rid,)).fetchone()[0],2)
        self.assertEqual(self.api('/api/media/'+mid,'DELETE').status_code,400)
        self.assertEqual(self.client.post('/api/media/'+mid+'/replace',data={'file':(self.image('blue'),'new.png')},headers={'X-CSRF-Token':self.csrf}).status_code,200)
        v['enabled']=False;self.api('/api/routes/'+str(rid),'PUT',v)
        self.assertEqual(self.client.get('/11').status_code,404)
        v['target']='javascript:alert(1)';self.assertEqual(self.api('/api/routes/'+str(rid),'PUT',v).status_code,400)
        v['target']='//evil.example';self.assertEqual(self.api('/api/routes/'+str(rid),'PUT',v).status_code,400)
        v['target']='/';v['slug']='admineight';self.assertEqual(self.api('/api/routes',data=v).status_code,400)
        self.assertEqual(self.client.post('/api/media',data={'file':(io.BytesIO(b'<script>alert(1)</script>'),'hack.png')},headers={'X-CSRF-Token':self.csrf}).status_code,400)
        home=self.client.get('/api/state').json['settings'];home['title']='<script>alert(1)</script>';home['image']=mid
        self.assertEqual(self.api('/api/settings',data=home).status_code,200)
        self.assertIn(b'&lt;script&gt;',self.client.get('/').data)
        self.api('/api/routes/'+str(rid),'DELETE');home['image']='';self.api('/api/settings',data=home)
        self.assertEqual(self.api('/api/media/'+mid,'DELETE').status_code,200)
        self.assertEqual(self.client.get('/media/'+mid).status_code,404)
        # Persisted settings survive a separate request/client.
        self.assertIn(b'&lt;script&gt;',app.test_client().get('/').data)
    def test_login_throttle(self):
        c=app.test_client();c.get('/admineight')
        with c.session_transaction() as s: token=s['csrf']
        for _ in range(8):self.assertEqual(c.post('/admineight',data={'csrf':token,'password':'wrong'}).status_code,401)
        self.assertEqual(c.post('/admineight',data={'csrf':token,'password':'wrong'}).status_code,429)

if __name__=='__main__':unittest.main()
