import os, json, secrets, sqlite3, re, time, hashlib
from pathlib import Path
from functools import wraps
from contextlib import contextmanager
from datetime import timedelta
from urllib.parse import urlsplit
from flask import Flask, request, session, render_template, redirect, jsonify, abort, send_file
from werkzeug.security import generate_password_hash, check_password_hash
from PIL import Image

ROOT = Path(__file__).resolve().parent
DATA = Path(os.environ.get('MARKOL_DATA', ROOT / 'data'))
DATA.mkdir(parents=True, exist_ok=True)
(DATA / 'uploads').mkdir(exist_ok=True)
CONFIG = DATA / 'config.json'
def write_config(value):
    tmp = CONFIG.with_suffix('.tmp')
    tmp.write_text(json.dumps(value), encoding='utf-8'); tmp.chmod(0o600); tmp.replace(CONFIG)
if not CONFIG.exists():
    password = secrets.token_urlsafe(30)
    write_config({'secret': secrets.token_hex(32), 'password_hash': generate_password_hash(password), 'epoch': 1})
    p = DATA / 'FIRST_LOGIN.txt'
    p.write_text('Admin: /admineight\nPassword: ' + password + '\nDelete this file after saving the password.\n', encoding='utf-8'); p.chmod(0o600)
    print('First admin password saved in data/FIRST_LOGIN.txt', flush=True)
config = json.loads(CONFIG.read_text())
app = Flask(__name__)
app.config.update(SECRET_KEY=config['secret'], MAX_CONTENT_LENGTH=512*1024*1024,
                  SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax',
                  SESSION_COOKIE_SECURE=os.environ.get('COOKIE_SECURE') == '1', PERMANENT_SESSION_LIFETIME=timedelta(hours=8))

if os.environ.get('TRUST_PROXY') == '1':
    from werkzeug.middleware.proxy_fix import ProxyFix
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1)

@contextmanager
def db():
    conn = sqlite3.connect(DATA / 'site.db', timeout=20); conn.row_factory = sqlite3.Row
    try:
        with conn:
            yield conn
    finally:
        conn.close()
with db() as c:
    c.executescript('''PRAGMA journal_mode=WAL;
    CREATE TABLE IF NOT EXISTS settings (id INTEGER PRIMARY KEY, body TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS routes (id INTEGER PRIMARY KEY, slug TEXT UNIQUE NOT NULL, title TEXT NOT NULL, kind TEXT NOT NULL, target TEXT NOT NULL, steps TEXT NOT NULL, enabled INTEGER NOT NULL DEFAULT 1, hits INTEGER NOT NULL DEFAULT 0, last_visit TEXT);
    CREATE TABLE IF NOT EXISTS media (id TEXT PRIMARY KEY, name TEXT NOT NULL, filename TEXT NOT NULL, kind TEXT NOT NULL, size INTEGER NOT NULL, created TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS attempts (key TEXT PRIMARY KEY, count INTEGER NOT NULL, until REAL NOT NULL);
    CREATE TABLE IF NOT EXISTS counters (name TEXT PRIMARY KEY, hits INTEGER DEFAULT 0);
    INSERT OR IGNORE INTO counters VALUES ('home',0);
    ''')
    c.execute('INSERT OR IGNORE INTO settings VALUES (1,?)', (json.dumps({'title':'Привет, добро пожаловать на markol.fun!', 'subtitle':'Маленький уголок большого интернета. Устраивайся поудобнее.', 'button':'Открыть Маркуйз', 'url':'https://markuiz.markol.fun', 'image':'', 'ticker':'MARKOL.FUN • Личный уголок интернета • Сделано с любопытством', 'footer':'Создавай. Пробуй. Возвращайся.'}),))

def settings():
    with db() as c: return json.loads(c.execute('SELECT body FROM settings WHERE id=1').fetchone()[0])
def csrf():
    if 'csrf' not in session: session['csrf'] = secrets.token_hex(24)
    return session['csrf']
app.jinja_env.globals['csrf'] = csrf

def authorized():
    cfg = json.loads(CONFIG.read_text())
    return session.get('admin') and session.get('epoch') == cfg['epoch']
def admin(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not authorized(): abort(401)
        return fn(*args, **kwargs)
    return wrapped
@app.before_request
def protect():
    if request.method in ('POST','PUT','DELETE','PATCH'):
        token = request.headers.get('X-CSRF-Token') or request.form.get('csrf','')
        if not session.get('csrf') or not secrets.compare_digest(token, session['csrf']): abort(403)
@app.after_request
def headers(response):
    response.headers['X-Content-Type-Options']='nosniff'
    response.headers['X-Frame-Options']='DENY'
    response.headers['Referrer-Policy']='no-referrer'
    response.headers['Content-Security-Policy']="default-src 'self'; img-src 'self' data:; media-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'"
    if request.path.startswith(('/admineight','/api/')): response.headers['Cache-Control']='no-store'
    return response
@app.errorhandler(400)
@app.errorhandler(401)
@app.errorhandler(403)
@app.errorhandler(404)
@app.errorhandler(409)
@app.errorhandler(413)
@app.errorhandler(429)
def error(e):
    messages={400:'Проверь поля формы.',401:'Войдите в админку.',403:'Сессия формы устарела. Обновите страницу.',404:'Этот ярлык потерялся.',409:'Этот адрес уже занят.',413:'Файл больше 512 МБ.',429:'Слишком много попыток. Попробуйте через 15 минут.'}
    message = e.description if e.description and e.code==400 else messages.get(e.code,'Ошибка')
    if request.path.startswith('/api/'): return jsonify(error=message),e.code
    return render_template('error.html', code=e.code, message=message),e.code

def target_ok(value):
    if not isinstance(value,str) or len(value)>2048 or any(ord(x)<32 for x in value) or '\\' in value: return False
    if value.startswith('/') and not value.startswith('//'): return True
    p=urlsplit(value)
    return p.scheme in ('http','https') and bool(p.hostname) and not p.username and not p.password

def media_list():
    with db() as c: return [dict(r) for r in c.execute('SELECT * FROM media ORDER BY created DESC')]
def route_dict(r):
    result=dict(r); result['steps']=json.loads(result['steps']); return result
@app.get('/')
def home():
    with db() as c:
        c.execute("UPDATE counters SET hits=hits+1 WHERE name='home'")
        count=c.execute("SELECT hits FROM counters WHERE name='home'").fetchone()[0]
    return render_template('home.html', s=settings(), count=count)
@app.route('/admineight',methods=['GET','POST'])
def login():
    if request.method=='POST':
        key=hashlib.sha256((request.remote_addr or '').encode()).hexdigest()
        with db() as c:
            c.execute('DELETE FROM attempts WHERE until < ?', (time.time(),))
            row=c.execute('SELECT * FROM attempts WHERE key=?',(key,)).fetchone()
            if row and row['count']>=8: abort(429)
            cfg=json.loads(CONFIG.read_text())
            if check_password_hash(cfg['password_hash'], request.form.get('password','')):
                c.execute('DELETE FROM attempts WHERE key=?',(key,))
                session.clear(); session.update(admin=True,epoch=cfg['epoch']); session.permanent=True
                return redirect('/admineight')
            c.execute('INSERT INTO attempts VALUES (?,1,?) ON CONFLICT(key) DO UPDATE SET count=count+1',(key,time.time()+900))
        return render_template('login.html',error='Пароль не подошёл.'),401
    return render_template('admin.html') if authorized() else render_template('login.html')
@app.post('/api/logout')
@admin
def logout():
    session.clear(); return jsonify(ok=True)
@app.get('/api/state')
@admin
def state():
    with db() as c:
        routes=[route_dict(r) for r in c.execute('SELECT * FROM routes ORDER BY id DESC')]
        hits=c.execute("SELECT hits FROM counters WHERE name='home'").fetchone()[0]
    return jsonify(settings=settings(),routes=routes,media=media_list(),home_hits=hits)
@app.post('/api/settings')
@admin
def save_settings():
    value=request.get_json() or {}; s={}
    for key,limit in [('title',200),('subtitle',1000),('button',80),('url',2048),('image',64),('ticker',400),('footer',200)]:
        v=value.get(key,'')
        if not isinstance(v,str) or len(v)>limit: abort(400)
        s[key]=v.strip()
    if not target_ok(s['url']): abort(400,description='Нужна ссылка https://… или путь /…')
    if s['image']:
        with db() as c:
            if not c.execute("SELECT id FROM media WHERE id=? AND kind='image'",(s['image'],)).fetchone(): abort(400)
    with db() as c: c.execute('UPDATE settings SET body=? WHERE id=1',(json.dumps(s),))
    return jsonify(ok=True)
@app.post('/api/password')
@admin
def password_change():
    value=request.get_json() or {}; cfg=json.loads(CONFIG.read_text())
    if not check_password_hash(cfg['password_hash'],value.get('current','')): abort(400,description='Текущий пароль неверный.')
    new=value.get('password','')
    if not isinstance(new,str) or not 20<=len(new)<=256: abort(400,description='Новый пароль должен содержать от 20 до 256 символов.')
    cfg['password_hash']=generate_password_hash(new); cfg['epoch']+=1; write_config(cfg)
    (DATA/'FIRST_LOGIN.txt').unlink(missing_ok=True)
    session.clear(); return jsonify(ok=True)
@app.post('/api/routes')
@app.put('/api/routes/<int:rid>')
@admin
def save_route(rid=None):
    v=request.get_json() or {}; slug=str(v.get('slug','')).strip().strip('/')
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,80}',slug) or slug.lower() in ('admineight','api','static','media','robots.txt','favicon.ico'): abort(400,description='Адрес: 1–80 латинских букв, цифр, - или _. Системные адреса заняты.')
    title=str(v.get('title',''))[:120]; kind=v.get('kind'); target=v.get('target','')
    if kind not in ('redirect','scenario') or not target_ok(target): abort(400,description='Проверь тип и конечную ссылку.')
    if target.split('?')[0].rstrip('/')=='/'+slug: abort(400,description='Нельзя перенаправлять ссылку саму на себя.')
    steps=v.get('steps',[]) if kind=='scenario' else []
    if not isinstance(steps,list) or (kind=='scenario' and not 1<=len(steps)<=30): abort(400,description='В сценарии нужно от 1 до 30 шагов.')
    cleaned=[]
    with db() as c:
        for step in steps:
            if not isinstance(step,dict): abort(400)
            m=c.execute('SELECT * FROM media WHERE id=?',(step.get('media'),)).fetchone()
            if not m: abort(400,description='Выберите существующий медиафайл в каждом шаге.')
            try: seconds=float(step.get('seconds',5))
            except (ValueError,TypeError): abort(400)
            if not 0.5<=seconds<=3600: abort(400,description='Время фото: от 0.5 до 3600 секунд.')
            cleaned.append({'media':m['id'],'seconds':seconds})
        args=(slug,title,kind,target,json.dumps(cleaned),int(bool(v.get('enabled',True))))
        try:
            if rid is None:
                rid=c.execute('INSERT INTO routes(slug,title,kind,target,steps,enabled) VALUES (?,?,?,?,?,?)',args).lastrowid
            else:
                if not c.execute('SELECT id FROM routes WHERE id=?',(rid,)).fetchone(): abort(404)
                c.execute('UPDATE routes SET slug=?,title=?,kind=?,target=?,steps=?,enabled=? WHERE id=?',args+(rid,))
        except sqlite3.IntegrityError: abort(409)
    return jsonify(ok=True,id=rid)
@app.delete('/api/routes/<int:rid>')
@admin
def delete_route(rid):
    with db() as c: c.execute('DELETE FROM routes WHERE id=?',(rid,))
    return jsonify(ok=True)

def identify(path):
    try:
        with Image.open(path) as im:
            fmt=im.format; im.verify()
        ext={'PNG':'png','JPEG':'jpg','GIF':'gif','WEBP':'webp'}.get(fmt)
        if ext: return 'image',ext
    except Exception: pass
    with path.open('rb') as f: h=f.read(64)
    if len(h)>12 and h[4:8]==b'ftyp': return 'video','mp4'
    if h.startswith(b'\x1aE\xdf\xa3'): return 'video','webm'
    abort(400,description='Поддерживаются PNG, JPG, GIF, WebP, MP4 и WebM. Содержимое файла должно соответствовать формату.')
@app.post('/api/media')
@app.post('/api/media/<mid>/replace')
@admin
def upload(mid=None):
    file=request.files.get('file')
    if not file or not file.filename: abort(400,description='Выберите файл.')
    old=None
    if mid:
        with db() as c: old=c.execute('SELECT * FROM media WHERE id=?',(mid,)).fetchone()
        if not old: abort(404)
    path=DATA/'uploads'/('tmp-'+secrets.token_hex(16))
    try:
        file.save(path); kind,ext=identify(path)
        if old and old['kind']!=kind: abort(400,description='Замена должна иметь тот же тип: фото на фото, видео на видео.')
        mid=mid or secrets.token_hex(16)
        filename=secrets.token_hex(20)+'.'+ext
        size=path.stat().st_size; path.rename(DATA/'uploads'/filename)
        with db() as c:
            c.execute('INSERT INTO media(id,name,filename,kind,size) VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name, filename=excluded.filename,size=excluded.size',(mid,Path(file.filename).name[:200],filename,kind,size))
        if old: (DATA/'uploads'/old['filename']).unlink(missing_ok=True)
    finally: path.unlink(missing_ok=True)
    return jsonify(ok=True,id=mid,url='/media/'+mid)
@app.delete('/api/media/<mid>')
@admin
def delete_media(mid):
    with db() as c:
        if settings().get('image')==mid or any(any(s['media']==mid for s in json.loads(r[0])) for r in c.execute('SELECT steps FROM routes')): abort(400,description='Этот файл используется на главной или в сценарии. Сначала уберите его оттуда.')
        row=c.execute('SELECT * FROM media WHERE id=?',(mid,)).fetchone()
        if not row: abort(404)
        c.execute('DELETE FROM media WHERE id=?',(mid,))
    (DATA/'uploads'/row['filename']).unlink(missing_ok=True)
    return jsonify(ok=True)
@app.get('/media/<mid>')
def media(mid):
    with db() as c: row=c.execute('SELECT * FROM media WHERE id=?',(mid,)).fetchone()
    if not row: abort(404)
    result=send_file(DATA/'uploads'/row['filename'],conditional=True,max_age=0)
    result.headers['Cache-Control']='no-cache'
    return result

def show_route(row,preview=False):
    r=route_dict(row)
    if r['kind']=='redirect' and not preview:
        response=redirect(r['target'],302); response.headers['Cache-Control']='no-store'; return response
    media_by_id={m['id']:m for m in media_list()}
    r['steps']=[dict(s,kind=media_by_id[s['media']]['kind']) for s in r['steps']]
    return render_template('player.html',route=r,preview=preview)
@app.get('/admineight/preview/<int:rid>')
@admin
def preview(rid):
    with db() as c: row=c.execute('SELECT * FROM routes WHERE id=?',(rid,)).fetchone()
    if not row: abort(404)
    return show_route(row,True)
@app.get('/<slug>')
def short(slug):
    with db() as c:
        row=c.execute('SELECT * FROM routes WHERE slug=? AND enabled=1',(slug,)).fetchone()
        if not row: abort(404)
        c.execute('UPDATE routes SET hits=hits+1,last_visit=CURRENT_TIMESTAMP WHERE id=?',(row['id'],))
    return show_route(row)
if __name__=='__main__':
    from waitress import serve
    host=os.environ.get('HOST','127.0.0.1'); port=int(os.environ.get('PORT','8098'))
    print(f'Markol.fun: http://{host}:{port}\nAdmin: /admineight',flush=True)
    serve(app,host=host,port=port,threads=8,max_request_body_size=512*1024*1024)
