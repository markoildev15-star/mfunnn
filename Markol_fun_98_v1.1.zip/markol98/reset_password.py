"""Run on your server: .venv/bin/python reset_password.py"""
import secrets
from app import CONFIG, DATA, write_config
import json
from werkzeug.security import generate_password_hash
cfg=json.loads(CONFIG.read_text())
password=secrets.token_urlsafe(30)
cfg['password_hash']=generate_password_hash(password);cfg['epoch']+=1
write_config(cfg)
p=DATA/'FIRST_LOGIN.txt';p.write_text('Admin: /admineight\nPassword: '+password+'\n',encoding='utf-8');p.chmod(0o600)
print('New password saved to',p,'All previous sessions revoked.')
